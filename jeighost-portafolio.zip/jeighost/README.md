# JEIGHOST - Portafolio Web

## 🎨 Portafolio Futurista - Poeta, Editor & Productor Musical

Portafolio web profesional con diseño futurista, animaciones 3D y colores negro, rojo y dorado.

---

## 📁 Estructura del Proyecto

```
/jeighost
├── index.html          # Home / Landing page
├── webs.html           # Proyectos web
├── video.html          # Edición de video
├── beats.html          # Producción musical
├── css/
│   └── style.css       # Estilos completos
├── js/
│   └── main.js         # JavaScript con animaciones
├── assets/
│   ├── images/         # Imágenes del sitio
│   ├── video.mp4       # Video destacado
│   └── audio/          # Archivos de audio
└── README.md
```

---

## 🚀 Características

### Diseño y Estética
- ✨ **Diseño futurista** con efectos de partículas animadas
- 🎨 **Paleta de colores**: Negro, Rojo (#ff0000) y Dorado (#ffd700)
- 🌟 **Animaciones 3D** en cards y botones (efecto tilt)
- 💫 **Efectos de glow** y sombras dinámicas
- 🔮 **Transiciones suaves** y profesionales

### Funcionalidades
- 🎵 **Reproductor de música** integrado con controles
- 🎬 **Galería de videos** con thumbnails
- 📱 **100% Responsive** (móvil, tablet, desktop)
- ⚡ **Optimizado para rendimiento** (lazy loading, debouncing)
- 🔍 **SEO optimizado** (meta tags completos)
- 🎯 **Navegación fija** siempre visible
- 🌐 **Compatible con todos los navegadores**

### Secciones
1. **Home**: Landing page con presentación y acceso rápido
2. **Webs**: Galería de proyectos web con jeighost.lat
3. **Video**: Galería de trabajos de edición
4. **Productor**: Reproductor + galería de beats y canciones

---

## 📝 Configuración

### 1. Imágenes
Reemplaza los placeholders en `/assets/images/` con tus propias imágenes:

```
assets/images/
├── jeighost-lat.jpg        # Logo/captura de jeighost.lat
├── project-2.jpg           # Proyectos futuros
├── project-3.jpg
├── video-thumb-1.jpg       # Thumbnails de videos
├── video-thumb-2.jpg
├── video-thumb-3.jpg
├── video-thumb-4.jpg
├── video-thumb-5.jpg
├── video-thumb-6.jpg
├── album-art.jpg           # Artwork del reproductor
├── beat1.jpg               # Covers de beats
├── beat2.jpg
├── beat3.jpg
├── beat4.jpg
├── beat5.jpg
└── beat6.jpg
```

**Tamaños recomendados:**
- Proyectos web: 1200x800px
- Thumbnails de video: 800x450px (16:9)
- Album art: 600x600px (1:1)
- Covers de beats: 500x500px (1:1)

### 2. Videos
Agrega tu video destacado en:
```
assets/video.mp4
```

### 3. Audio
Agrega tus tracks en:
```
assets/audio/
├── track1.mp3
├── track2.mp3
└── track3.mp3
```

### 4. Enlaces
Actualiza los enlaces en los archivos HTML:
- **YouTube**: Línea en `beats.html` con `href="https://youtube.com/@jeighost"`
- **SoundCloud**: Línea en `beats.html` con `href="https://soundcloud.com/jeighost"`

---

## 🎯 Personalización

### Colores
Edita las variables CSS en `/css/style.css`:

```css
:root {
    --color-red: #ff0000;
    --color-gold: #ffd700;
    /* Agrega tus propios colores */
}
```

### Fuentes
Cambiar tipografías en el `<head>` de cada HTML y actualizar variables:

```css
:root {
    --font-primary: 'TuFuente', sans-serif;
    --font-secondary: 'OtraFuente', sans-serif;
}
```

### Contenido
Edita directamente el contenido en cada archivo HTML:
- Títulos de proyectos
- Descripciones
- Información de tracks
- Enlaces externos

---

## ⚡ Optimización SEO

### Meta Tags Incluidos
- ✅ Description
- ✅ Keywords
- ✅ Author
- ✅ Open Graph (Facebook, Twitter)
- ✅ Viewport para móviles

### Mejoras Recomendadas
1. Crear archivo `sitemap.xml`
2. Agregar `robots.txt`
3. Implementar Google Analytics
4. Configurar Schema.org markup
5. Agregar favicon y apple-touch-icon

---

## 🚀 Deployment

### Hosting Recomendado
- **Netlify** (gratis, con SSL)
- **Vercel** (gratis, deploy automático)
- **GitHub Pages** (gratis, para repos públicos)
- **Cloudflare Pages** (gratis, rápido)

### Pasos para Deploy en Netlify
1. Sube el proyecto a GitHub
2. Conecta el repo en Netlify
3. Build settings: ninguno (HTML estático)
4. Deploy directory: `/` (raíz)
5. ¡Listo!

---

## 📱 Compatibilidad

- ✅ Chrome / Edge (Chromium)
- ✅ Firefox
- ✅ Safari / iOS Safari
- ✅ Opera
- ✅ Samsung Internet
- ✅ Móviles Android/iOS

---

## 🎨 Recursos Adicionales

### Generadores de Imágenes Placeholder
- [Unsplash](https://unsplash.com) - Fotos gratis de alta calidad
- [Pexels](https://pexels.com) - Videos y fotos gratis
- [Canva](https://canva.com) - Diseño de covers y thumbnails

### Herramientas de Optimización
- [TinyPNG](https://tinypng.com) - Comprimir imágenes
- [FFmpeg](https://ffmpeg.org) - Comprimir videos
- [Google PageSpeed](https://pagespeed.web.dev) - Test de velocidad

---

## 📄 Licencia

Diseñado y desarrollado para **Jeighost** © 2024

---

## 🤝 Soporte

Para dudas o modificaciones, contacta al desarrollador.

**¡Disfruta tu portafolio futurista!** ✨🎨🎵
